"""Experimental module exposing a function a `MISSING` sentinel."""

from pydantic_core import MISSING

__all__ = ('MISSING',)
